module.exports = Object.freeze({
    greetings:{
        mainMenu:[
            `Really you're here, tell you what, why don't you choose between the full vehicle tour, or just ask me question about this amazing ${carMake} ${carModel}`,
            `Isn't this ${carMake} ${carModel} beautiful? Do you want to experience the full tour or ask any question you like?`,
        ]
    },
    confirmations:{
        postVehicleRegistration: `Thank you for registering this ${carMake} ${carModel}. It is ready for the user to `
    }


});