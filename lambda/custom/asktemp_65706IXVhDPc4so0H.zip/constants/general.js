module.exports = Object.freeze({
    greetings:{
        mainMenu:[
            `Really you're here, tell you what, why don't you choose between the full vehicle tour, or just ask me question about this amazing `,
            `Isn't this %s %t beautiful? Maybe you would like to experience a full tour or just ask me any question you like.`,
        ]
    },
    confirmations:{
        postVehicleRegistration: `Thank you for registering this vehicle. It is ready for the user to `
    }


});